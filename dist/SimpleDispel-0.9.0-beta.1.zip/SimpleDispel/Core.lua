local addonName, addon = ...

local PREFIX = "|cff4ee6a8SimpleDispel|r:"
local FILTER_HELP = "mine (HARMFUL|RAID), group, all"
local BUTTON_GAP = 6
local FRAME_PADDING = 4
local HANDLE_HEIGHT = 22
local DEFAULT_X = 0
local DEFAULT_Y = -180
local MIN_SCALE = 0.60
local MAX_SCALE = 2.00

addon.buttons = {}
addon.auraContainers = {}
addon.pendingSpellRefresh = false
addon.pendingLayoutRefresh = false

local function Print(message)
    print(PREFIX, message)
end

addon.Print = Print

local function GetAddonVersion()
    if C_AddOns and C_AddOns.GetAddOnMetadata then
        return C_AddOns.GetAddOnMetadata(addonName, "Version") or "unknown"
    end
    if GetAddOnMetadata then
        return GetAddOnMetadata(addonName, "Version") or "unknown"
    end
    return "unknown"
end

local function InitializeDatabase()
    if type(SimpleDispelDB) ~= "table" then
        SimpleDispelDB = {}
    end

    SimpleDispelDB.schemaVersion = 2
    SimpleDispelDB.filterMode = SimpleDispelDB.filterMode or "mine"
    if type(SimpleDispelDB.locked) ~= "boolean" then
        SimpleDispelDB.locked = false
    end
    if type(SimpleDispelDB.scale) ~= "number" then
        SimpleDispelDB.scale = 1
    end
    if type(SimpleDispelDB.position) ~= "table" then
        SimpleDispelDB.position = {
            point = "CENTER",
            relativePoint = "CENTER",
            x = DEFAULT_X,
            y = DEFAULT_Y,
        }
    end
    addon.db = SimpleDispelDB
end

local function SavePosition()
    if not addon.root or InCombatLockdown() then
        return
    end

    local point, _, relativePoint, x, y = addon.root:GetPoint(1)
    addon.db.position = {
        point = point or "CENTER",
        relativePoint = relativePoint or "CENTER",
        x = tonumber(x) or DEFAULT_X,
        y = tonumber(y) or DEFAULT_Y,
    }
end

local function UpdateLockState()
    if not addon.root or not addon.dragHandle then
        return
    end

    local canDrag = not addon.db.locked and not InCombatLockdown()
    addon.dragHandle:EnableMouse(canDrag)
    addon.dragHandle:SetAlpha(addon.db.locked and 0.72 or 1)
    addon.title:SetText(addon.db.locked and "SimpleDispel" or "SimpleDispel  |cffaaaaaa(drag)|r")
end

local function ApplyRootSettings()
    if not addon.root then
        return
    end
    if InCombatLockdown() then
        addon.pendingLayoutRefresh = true
        return
    end

    local position = addon.db.position or {}
    addon.root:SetScale(math.max(MIN_SCALE, math.min(MAX_SCALE, addon.db.scale or 1)))
    addon.root:ClearAllPoints()
    addon.root:SetPoint(
        position.point or "CENTER",
        UIParent,
        position.relativePoint or "CENTER",
        tonumber(position.x) or DEFAULT_X,
        tonumber(position.y) or DEFAULT_Y
    )
    addon.pendingLayoutRefresh = false
    UpdateLockState()
end

local function CreateUI()
    local buttonSize = addon.SecureButtons.BUTTON_SIZE or 48
    local buttonCount = 5
    local frameWidth = (buttonSize * buttonCount)
        + (BUTTON_GAP * (buttonCount - 1))
        + (FRAME_PADDING * 2)
    local frameHeight = buttonSize + HANDLE_HEIGHT + FRAME_PADDING

    local root = CreateFrame("Frame", "SimpleDispelFrame", UIParent)
    root:SetSize(frameWidth, frameHeight)
    root:SetFrameStrata("MEDIUM")
    root:SetMovable(true)
    root:SetClampedToScreen(true)

    local background = root:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints(root)
    background:SetColorTexture(0.015, 0.018, 0.024, 0.88)

    local dragHandle = CreateFrame("Frame", nil, root)
    dragHandle:SetPoint("TOPLEFT", root, "TOPLEFT", 0, 0)
    dragHandle:SetPoint("TOPRIGHT", root, "TOPRIGHT", 0, 0)
    dragHandle:SetHeight(HANDLE_HEIGHT)
    dragHandle:RegisterForDrag("LeftButton")
    dragHandle:SetScript("OnDragStart", function()
        if addon.db.locked or InCombatLockdown() then
            return
        end
        root:StartMoving()
    end)
    dragHandle:SetScript("OnDragStop", function()
        root:StopMovingOrSizing()
        SavePosition()
    end)

    local handleBackground = dragHandle:CreateTexture(nil, "BACKGROUND")
    handleBackground:SetAllPoints(dragHandle)
    handleBackground:SetColorTexture(0.055, 0.065, 0.08, 0.94)

    local title = dragHandle:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    title:SetPoint("CENTER", dragHandle, "CENTER", 0, 0)

    local definitions = {
        { unit = "player", name = "SimpleDispelPlayerButton", label = "YOU" },
        { unit = "party1", name = "SimpleDispelParty1Button", label = "P1" },
        { unit = "party2", name = "SimpleDispelParty2Button", label = "P2" },
        { unit = "party3", name = "SimpleDispelParty3Button", label = "P3" },
        { unit = "party4", name = "SimpleDispelParty4Button", label = "P4" },
    }

    local filterString = addon.AuraDisplay:GetFilter(addon.db.filterMode)
    local auraFailure

    for index, definition in ipairs(definitions) do
        local button = addon.SecureButtons:Create(
            root,
            definition.name,
            definition.unit,
            definition.label
        )
        local x = FRAME_PADDING + ((index - 1) * (buttonSize + BUTTON_GAP))
        button:SetPoint("BOTTOMLEFT", root, "BOTTOMLEFT", x, FRAME_PADDING)
        addon.buttons[#addon.buttons + 1] = button

        local container, auraError = addon.AuraDisplay:Create(
            button,
            definition.unit,
            filterString
        )
        if container then
            addon.auraContainers[#addon.auraContainers + 1] = container
        else
            auraFailure = auraFailure or tostring(auraError)
        end
    end

    addon.root = root
    addon.dragHandle = dragHandle
    addon.title = title
    addon.auraError = auraFailure
    ApplyRootSettings()
    if auraFailure then
        Print("Aura display unavailable: " .. auraFailure)
    end
end

function addon:RefreshSpell()
    if InCombatLockdown() then
        self.pendingSpellRefresh = true
        return false
    end

    local spell = self.Spells:Resolve()
    for _, button in ipairs(self.buttons) do
        self.SecureButtons:SetSpell(button, spell)
    end

    self.activeSpell = spell
    self.pendingSpellRefresh = false
    return true
end

local function PrintStatus()
    local gameVersion, build, _, tocVersion = GetBuildInfo()
    local supported, supportError = addon.AuraDisplay:IsSupported()
    local spell = addon.activeSpell

    Print(string.format(
        "addon=%s game=%s build=%s toc=%s combat=%s",
        GetAddonVersion(),
        tostring(gameVersion),
        tostring(build),
        tostring(tocVersion),
        tostring(InCombatLockdown())
    ))
    Print(string.format(
        "auraContainer=%s filter=%s buttons=%d locked=%s scale=%.2f",
        supported and "yes" or ("no: " .. tostring(supportError)),
        addon.AuraDisplay:GetFilter(addon.db.filterMode),
        #addon.buttons,
        tostring(addon.db.locked),
        addon.db.scale or 1
    ))

    if spell then
        Print(string.format(
            "spell=%s (%d), source=%s, spellbookKnown=%s",
            spell.name,
            spell.id,
            tostring(spell.source),
            tostring(spell.known)
        ))
    else
        Print("spell=none; use /sd spell <spellID> to set an out-of-combat override")
    end

    if addon.auraError then
        Print("last aura error: " .. addon.auraError)
    end
end

local function PrintHelp()
    Print("/sd status")
    Print("/sd spell auto | /sd spell <spellID>")
    Print("/sd filter <" .. FILTER_HELP .. "> (then /reload)")
    Print("/sd lock | /sd unlock | /sd scale <0.60-2.00> | /sd reset")
end

local function HandleSpellCommand(argument)
    if argument == "auto" then
        addon.db.manualSpellID = nil
        addon:RefreshSpell()
        Print("spell selection set to auto")
        return
    end

    local spellID = tonumber(argument)
    local info = spellID and addon.Spells:GetInfo(spellID)
    if not info then
        Print("unknown spell ID: " .. tostring(argument))
        return
    end

    addon.db.manualSpellID = spellID
    addon:RefreshSpell()
    Print(string.format("manual spell set to %s (%d)", info.name, spellID))
    if InCombatLockdown() then
        Print("secure attributes will update after combat")
    end
end

local function HandleFilterCommand(argument)
    if not addon.AuraDisplay.Filters[argument] then
        Print("filter must be one of: " .. FILTER_HELP)
        return
    end

    addon.db.filterMode = argument
    Print("filter set to " .. addon.AuraDisplay.Filters[argument] .. "; run /reload to rebuild containers")
end

local function HandleLockCommand(locked)
    addon.db.locked = locked
    ApplyRootSettings()
    Print(locked and "frame locked" or "frame unlocked; drag the title bar to move")
    if InCombatLockdown() then
        Print("layout will update after combat")
    end
end

local function HandleScaleCommand(argument)
    local scale = tonumber(argument)
    if not scale or scale < MIN_SCALE or scale > MAX_SCALE then
        Print(string.format("scale must be between %.2f and %.2f", MIN_SCALE, MAX_SCALE))
        return
    end

    addon.db.scale = scale
    ApplyRootSettings()
    Print(string.format("scale set to %.2f", scale))
    if InCombatLockdown() then
        Print("layout will update after combat")
    end
end


local function ResetLayout()
    addon.db.position = {
        point = "CENTER",
        relativePoint = "CENTER",
        x = DEFAULT_X,
        y = DEFAULT_Y,
    }
    addon.db.scale = 1
    ApplyRootSettings()
    Print("position and scale reset")
    if InCombatLockdown() then
        Print("layout will update after combat")
    end
end

local function HandleSlashCommand(message)
    local command, argument = string.match(message or "", "^%s*(%S*)%s*(.-)%s*$")
    command = string.lower(command or "")
    argument = string.lower(argument or "")

    if command == "status" then
        PrintStatus()
    elseif command == "spell" then
        HandleSpellCommand(argument)
    elseif command == "filter" then
        HandleFilterCommand(argument)
    elseif command == "lock" then
        HandleLockCommand(true)
    elseif command == "unlock" then
        HandleLockCommand(false)
    elseif command == "scale" then
        HandleScaleCommand(argument)
    elseif command == "reset" then
        ResetLayout()
    else
        PrintHelp()
    end
end

local function RegisterSlashCommands()
    SLASH_SIMPLEDISPEL1 = "/sd"
    SLASH_SIMPLEDISPEL2 = "/simpledispel"
    SlashCmdList.SIMPLEDISPEL = HandleSlashCommand
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon ~= addonName then
            return
        end

        self:UnregisterEvent("ADDON_LOADED")
        InitializeDatabase()
        RegisterSlashCommands()
        CreateUI()

        self:RegisterEvent("PLAYER_LOGIN")
        self:RegisterEvent("PLAYER_REGEN_DISABLED")
        self:RegisterEvent("PLAYER_REGEN_ENABLED")
        self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
        self:RegisterEvent("SPELLS_CHANGED")
        self:RegisterEvent("TRAIT_CONFIG_UPDATED")
        return
    end

    if event == "PLAYER_LOGIN" then
        addon:RefreshSpell()
        Print("v" .. GetAddonVersion() .. " loaded; use /sd status")
    elseif event == "PLAYER_REGEN_ENABLED" then
        if addon.pendingSpellRefresh then
            addon:RefreshSpell()
        end
        if addon.pendingLayoutRefresh then
            ApplyRootSettings()
        else
            UpdateLockState()
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        UpdateLockState()
    elseif event == "PLAYER_SPECIALIZATION_CHANGED"
        or event == "SPELLS_CHANGED"
        or event == "TRAIT_CONFIG_UPDATED" then
        addon:RefreshSpell()
    end
end)
