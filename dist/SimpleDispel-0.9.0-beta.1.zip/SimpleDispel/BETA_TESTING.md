# SimpleDispel 0.9.0-beta.1 副本实测

这个版本已经具备五人小队的完整基本路径，但尚未经过 WoW 12.1 正式服战斗内验证。第一次建议排普通或英雄地下城，不要直接用于高层钥匙或重要团队活动。

## 1. 安装与启动

1. 把插件目录放到 `_retail_/Interface/AddOns/SimpleDispel`。
2. 确认 `SimpleDispel.toc` 就在该目录内，没有多套一层文件夹。
3. 在角色选择界面启用 SimpleDispel。
4. 建议首次测试前输入 `/console scriptErrors 1`，然后 `/reload`。

登录后应看到一个 `YOU` 方块；组队后会按固定顺序出现 `P1`–`P4`。拖动标题栏定位，使用 `/sd lock` 锁定。

## 2. 下本前检查

输入：

```text
/sd status
```

正常结果应包含：

- `addon=0.9.0-beta.1`
- `auraContainer=yes`
- `buttons=5`
- `filter=HARMFUL|RAID`
- `spell=技能名称 (spellID)`

如果显示 `spell=none`，先确认当前职业或专精确实有友方驱散。若自动识别漏掉了已学会技能，可将鼠标移到法术书里的驱散技能上查 spell ID，然后脱战输入：

```text
/sd spell <spellID>
```

恢复自动选择：`/sd spell auto`。

## 3. 一次副本需要验证的内容

保持怪物为当前目标，等待自己或队友出现你能处理的 debuff：

1. 对应的 `YOU`/`P1`–`P4` 方块应出现 debuff 图标。
2. 直接点击图标所在方块，应对该固定成员施放驱散。
3. 当前怪物目标不应改变。
4. debuff 消失后，图标应自行消失。
5. 队友离队、进队或战斗中死亡时，不应出现 protected/forbidden 错误。
6. 打完整个地下城后，界面仍能点击，位置和缩放在 `/reload` 后仍保留。

特别留意两个可区分的问题：

- 图标出现，点击方块边缘能驱散，但点击图标本身不行：属于 Aura Button 吞点击。
- 没有图标，但盲点对应方块可以驱散：安全施法正常，Aura 过滤或显示路径有问题。

## 4. 第一优先级错误

遇到以下任一情况就停止继续依赖该版本，并记录完整 Lua 错误：

- `ADDON_ACTION_FORBIDDEN`
- secret-value 或 forbidden-frame 错误
- 点击了 Pn 却驱散到另一名成员
- 点击改变了当前目标
- 进战后按钮失效，出战后仍不能恢复

回报时请贴：

```text
/sd status 的全部输出：
职业/专精：
副本与触发 debuff：
图标显示：正常 / 未显示 / 显示错误
点击图标：成功 / 失败
当前目标保持：是 / 否
完整 Lua 错误：
```

## 5. 命令速查

```text
/sd unlock             解锁标题栏拖动
/sd lock               锁定位置
/sd scale 0.60-2.00    调整整体缩放
/sd reset              恢复默认位置与 1.0 缩放
/sd status             输出诊断信息
```

过滤器默认保持 `mine`。`group` 和 `all` 只用于排查显示问题，修改后需要 `/reload`：

```text
/sd filter mine
/reload
```
