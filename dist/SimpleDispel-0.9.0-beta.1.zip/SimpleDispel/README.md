# SimpleDispel

一个面向 World of Warcraft 正式服 12.1+ 的轻量点击驱散插件。

当前版本：`0.9.0-beta.1`。它预创建 `player` 与 `party1`–`party4` 五个固定安全按钮，点击对应方块会直接对该单位施放角色当前学会的友方驱散，不改变当前目标。插件只让游戏自身的 Aura Container 显示系统过滤后的一个可驱散效果，不读取或分析受保护的 aura 数据。

## 使用

将整个目录复制为：

```text
World of Warcraft/_retail_/Interface/AddOns/SimpleDispel
```

进入游戏后拖动标题栏调整位置，再输入：

```text
/sd lock
```

常用命令：

```text
/sd status
/sd lock
/sd unlock
/sd scale 1.0
/sd reset
/sd spell auto
/sd spell <spellID>
```

进副本前请查看 [BETA_TESTING.md](BETA_TESTING.md)。完整范围、阶段计划以及 12.1 API 硬限制的停止规则见 [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md)。原先的两按钮技术验证记录保留在 [STAGE1_TESTING.md](STAGE1_TESTING.md)。
